import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Timer,
  Pause,
  Play,
  RotateCcw,
  Shuffle,
  Trophy,
  Volume2,
  VolumeX,
  Zap,
} from "lucide-react";

import { ITEM_LABEL, ItemIcon } from "@/components/arcade/ItemIcon";
import { Button } from "@/components/ui/button";
import {
  comboMultiplier,
  getRule,
  ROUND_SECONDS,
  TIME_PENALTY,
  nextShiftDelay,
  pickNextRule,
  resolveCatch,
  type ItemKind,
  type Rule,
} from "@/lib/game/rules";
import { sfx } from "@/lib/game/sound";
import { cn } from "@/lib/utils";

const W = 420;
const H = 620;
const BASE_PADDLE = 96;
const PADDLE_H = 14;
const BEST_KEY = "glitch-arcade-best";

type Status = "idle" | "playing" | "paused" | "over";

interface Item {
  x: number;
  y: number;
  r: number;
  kind: ItemKind;
  rot: number;
  spin: number;
  phase: number;
  vy: number;
  dead?: boolean;
}
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
}
interface Floater {
  x: number;
  y: number;
  text: string;
  life: number;
  color: string;
}
interface World {
  t: number;
  bgT: number;
  nextShift: number;
  spawnTimer: number;
  items: Item[];
  particles: Particle[];
  floaters: Floater[];
  paddleX: number;
  paddleW: number;
  paddleY: number;
  rule: Rule;
  score: number;
  timeLeft: number;
  streak: number;
  shifts: number;
  shake: number;
  slowmo: number;
  flash: number;
  flashColor: string;
  invuln: number;
}
interface Palette {
  bg: string;
  fg: string;
  good: string;
  bad: string;
  gold: string;
  primary: string;
  secondary: string;
  accent: string;
}

function createWorld(): World {
  return {
    t: 0,
    bgT: 0,
    nextShift: 6 + Math.random() * 4,
    spawnTimer: 0.6,
    items: [],
    particles: [],
    floaters: [],
    paddleX: W / 2,
    paddleW: BASE_PADDLE,
    paddleY: H - 48,
    rule: getRule("classic"),
    score: 0,
    timeLeft: ROUND_SECONDS,
    streak: 0,
    shifts: 0,
    shake: 0,
    slowmo: 0,
    flash: 0,
    flashColor: "",
    invuln: 0,
  };
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

function starPath(ctx: CanvasRenderingContext2D, spikes: number, outer: number, inner: number) {
  ctx.beginPath();
  for (let i = 0; i < spikes * 2; i++) {
    const r = i % 2 === 0 ? outer : inner;
    const a = (Math.PI / spikes) * i - Math.PI / 2;
    if (i === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
    else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
  }
  ctx.closePath();
}

interface LogEntry {
  rule: Rule;
  key: number;
  at: number;
}

export function RuleBreakerGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const worldRef = useRef<World>(createWorld());
  const statusRef = useRef<Status>("idle");
  const inputRef = useRef({ left: false, right: false, pointerX: null as number | null });
  const mutedRef = useRef(false);
  const bestRef = useRef(0);

  const [status, setStatusState] = useState<Status>("idle");
  const [hud, setHud] = useState({ score: 0, time: ROUND_SECONDS, combo: 1, shifts: 0 });
  const [best, setBest] = useState(0);
  const [rule, setRule] = useState<Rule>(getRule("classic"));
  const [banner, setBanner] = useState<{ rule: Rule; key: number } | null>(null);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [muted, setMuted] = useState(false);
  const [newBest, setNewBest] = useState(false);

  const setStatus = useCallback((s: Status) => {
    statusRef.current = s;
    setStatusState(s);
  }, []);

  const playSound = useCallback((fn: () => void) => {
    if (!mutedRef.current) fn();
  }, []);

  // Load best score from this device.
  useEffect(() => {
    const saved = Number(window.localStorage.getItem(BEST_KEY) || 0);
    if (Number.isFinite(saved)) {
      bestRef.current = saved;
      setBest(saved);
    }
  }, []);

  const startGame = useCallback(() => {
    worldRef.current = createWorld();
    inputRef.current.pointerX = null;
    setRule(getRule("classic"));
    setBanner(null);
    setLog([]);
    setHud({ score: 0, time: ROUND_SECONDS, combo: 1, shifts: 0 });
    setNewBest(false);
    setStatus("playing");
    playSound(sfx.start);
  }, [playSound, setStatus]);

  const togglePause = useCallback(() => {
    const s = statusRef.current;
    if (s === "playing") setStatus("paused");
    else if (s === "paused") setStatus("playing");
    else startGame();
  }, [setStatus, startGame]);

  // Main game loop.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const css = getComputedStyle(document.documentElement);
    const v = (n: string) => css.getPropertyValue(n).trim() || "#ffffff";
    const pal: Palette = {
      bg: v("--background"),
      fg: v("--foreground"),
      good: v("--game-good"),
      bad: v("--game-bad"),
      gold: v("--game-gold"),
      primary: v("--primary"),
      secondary: v("--secondary"),
      accent: v("--accent"),
    };
    const colorOf = (k: ItemKind) => (k === "green" ? pal.good : k === "red" ? pal.bad : pal.gold);

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = W * dpr;
      canvas.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    const burst = (w: World, x: number, y: number, color: string, n: number) => {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const s = 60 + Math.random() * 220;
        const max = 0.4 + Math.random() * 0.5;
        w.particles.push({
          x,
          y,
          vx: Math.cos(a) * s,
          vy: Math.sin(a) * s,
          life: max,
          max,
          color,
          size: 2 + Math.random() * 3,
        });
      }
    };

    const floater = (w: World, x: number, y: number, text: string, color: string) => {
      w.floaters.push({ x, y, text, life: 0.9, color });
    };

    const gameOver = (w: World) => {
      statusRef.current = "over";
      setStatusState("over");
      playSound(sfx.over);
      burst(w, w.paddleX, w.paddleY, pal.primary, 50);
      if (w.score > bestRef.current) {
        bestRef.current = w.score;
        setBest(w.score);
        setNewBest(true);
        try {
          window.localStorage.setItem(BEST_KEY, String(w.score));
        } catch {
          /* storage unavailable */
        }
      }
    };

    const shift = (w: World) => {
      const next = pickNextRule(w.rule.id);
      w.rule = next;
      w.nextShift = w.t + nextShiftDelay();
      w.shifts += 1;
      w.slowmo = 1.1;
      w.flash = 0.8;
      w.flashColor = pal.secondary;
      w.shake = 0.15;
      const key = performance.now() + Math.random();
      const at = Math.floor(w.t);
      setRule(next);
      setBanner({ rule: next, key });
      setLog((l) => [{ rule: next, key, at }, ...l].slice(0, 6));
      playSound(sfx.shift);
    };

    const onCatch = (w: World, it: Item) => {
      const res = resolveCatch(w.rule, it.kind);
      if (res.lifeLost) {
        burst(w, it.x, it.y, pal.bad, 26);
        if (w.invuln > 0) return;
        w.timeLeft = Math.max(0, w.timeLeft - TIME_PENALTY);
        w.streak = 0;
        w.shake = 0.35;
        w.flash = 1;
        w.flashColor = pal.bad;
        w.invuln = 1.2;
        floater(w, it.x, it.y, `-${TIME_PENALTY}s`, pal.bad);
        playSound(sfx.hit);
        if (w.timeLeft <= 0) gameOver(w);
      } else {
        burst(w, it.x, it.y, colorOf(it.kind), it.kind === "star" ? 30 : 16);
        w.streak += 1;
        const gained = res.points * comboMultiplier(w.streak);
        w.score += gained;
        floater(w, it.x, it.y, `+${gained}`, colorOf(it.kind));
        playSound(it.kind === "star" ? sfx.star : sfx.catch);
      }
    };

    const onMiss = (w: World, it: Item) => {
      if (it.kind === "star") return;
      if (w.rule.dodge) {
        w.score += w.rule.points;
      } else if (w.rule.good.includes(it.kind)) {
        w.streak = 0;
      }
    };

    const spawn = (w: World) => {
      const roll = Math.random();
      const kind: ItemKind = roll < 0.07 ? "star" : roll < 0.55 ? "green" : "red";
      const r = kind === "star" ? 15 : 13 + Math.random() * 4;
      w.items.push({
        x: r + Math.random() * (W - r * 2),
        y: w.rule.flip ? H + 20 : -20,
        r,
        kind,
        rot: Math.random() * 6,
        spin: (Math.random() - 0.5) * 4,
        phase: Math.random() * 6,
        vy: 150 + Math.min(w.t, 150) * 1.6 + Math.random() * 40,
      });
    };

    const updateFx = (w: World, dt: number) => {
      w.shake = Math.max(0, w.shake - dt);
      w.flash = Math.max(0, w.flash - dt * 2.2);
      w.invuln = Math.max(0, w.invuln - dt);
      for (const p of w.particles) {
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vx *= 0.94;
        p.vy *= 0.94;
        p.life -= dt;
      }
      w.particles = w.particles.filter((p) => p.life > 0);
      for (const f of w.floaters) {
        f.y -= 50 * dt;
        f.life -= dt;
      }
      w.floaters = w.floaters.filter((f) => f.life > 0);
    };

    const update = (w: World, realDt: number) => {
      w.slowmo = Math.max(0, w.slowmo - realDt);
      const dt = realDt * (w.slowmo > 0 ? 0.3 : 1);
      w.t += dt;
      updateFx(w, realDt);
      w.timeLeft -= realDt;
      if (w.timeLeft <= 0) {
        w.timeLeft = 0;
        gameOver(w);
        return;
      }

      if (w.t >= w.nextShift) shift(w);
      const r = w.rule;

      // Paddle movement
      const inp = inputRef.current;
      if (inp.pointerX !== null) {
        const target = r.reverse ? W - inp.pointerX : inp.pointerX;
        w.paddleX += (target - w.paddleX) * Math.min(1, realDt * 16);
      } else {
        let dir = (inp.right ? 1 : 0) - (inp.left ? 1 : 0);
        if (r.reverse) dir = -dir;
        w.paddleX += dir * 480 * realDt;
      }
      w.paddleW += (BASE_PADDLE * r.paddle - w.paddleW) * Math.min(1, realDt * 8);
      const targetY = r.flip ? 48 : H - 48;
      w.paddleY += (targetY - w.paddleY) * Math.min(1, realDt * 6);
      w.paddleX = clamp(w.paddleX, w.paddleW / 2, W - w.paddleW / 2);

      // Spawning
      w.spawnTimer -= dt;
      if (w.spawnTimer <= 0) {
        spawn(w);
        w.spawnTimer = Math.max(0.3, 0.85 - w.t * 0.005) / Math.max(1, r.speed * 0.8);
      }

      // Items
      const dir = r.flip ? -1 : 1;
      for (const it of w.items) {
        it.y += dir * it.vy * r.speed * dt;
        if (r.wind) {
          it.x = clamp(it.x + Math.sin(w.t * 1.4 + it.phase) * r.wind * dt, it.r, W - it.r);
        }
        it.rot += it.spin * dt;
        if (
          Math.abs(it.y - w.paddleY) < it.r + PADDLE_H / 2 &&
          Math.abs(it.x - w.paddleX) < w.paddleW / 2 + it.r * 0.5
        ) {
          it.dead = true;
          onCatch(w, it);
          if (statusRef.current !== "playing") break;
          continue;
        }
        if (it.y > H + 40 || it.y < -40) {
          it.dead = true;
          onMiss(w, it);
        }
      }
      w.items = w.items.filter((i) => !i.dead);
    };

    const drawItem = (it: Item) => {
      ctx.save();
      ctx.translate(it.x, it.y);
      ctx.rotate(it.rot);
      const color = colorOf(it.kind);
      ctx.shadowColor = color;
      ctx.shadowBlur = 18;
      ctx.fillStyle = color;
      if (it.kind === "green") {
        ctx.beginPath();
        ctx.arc(0, 0, it.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.globalAlpha = 0.5;
        ctx.fillStyle = pal.fg;
        ctx.beginPath();
        ctx.arc(-it.r * 0.3, -it.r * 0.3, it.r * 0.28, 0, Math.PI * 2);
        ctx.fill();
      } else if (it.kind === "red") {
        starPath(ctx, 8, it.r * 1.15, it.r * 0.62);
        ctx.fill();
      } else {
        starPath(ctx, 5, it.r * 1.2, it.r * 0.52);
        ctx.fill();
      }
      ctx.restore();
    };

    const draw = (w: World, s: Status) => {
      ctx.save();
      ctx.fillStyle = pal.bg;
      ctx.fillRect(0, 0, W, H);
      if (w.shake > 0) {
        const m = (w.shake / 0.35) * 10;
        ctx.translate((Math.random() - 0.5) * m, (Math.random() - 0.5) * m);
      }

      // Grid
      ctx.strokeStyle = pal.secondary;
      ctx.lineWidth = 1;
      ctx.globalAlpha = 0.12;
      ctx.beginPath();
      for (let x = 0; x <= W; x += 35) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
      }
      const off = ((w.bgT * 40) % 35) * (w.rule.flip ? -1 : 1);
      for (let y = -35; y <= H + 35; y += 35) {
        ctx.moveTo(0, y + off);
        ctx.lineTo(W, y + off);
      }
      ctx.stroke();

      // Danger zone glow near the paddle
      const zoneTop = w.rule.flip;
      const grad = ctx.createLinearGradient(0, zoneTop ? 0 : H, 0, zoneTop ? 140 : H - 140);
      grad.addColorStop(0, pal.primary);
      grad.addColorStop(1, "transparent");
      ctx.globalAlpha = 0.14;
      ctx.fillStyle = grad;
      ctx.fillRect(0, zoneTop ? 0 : H - 140, W, 140);
      ctx.globalAlpha = 1;

      for (const it of w.items) drawItem(it);

      // Paddle
      if (s !== "over") {
        let alpha = 1;
        if (w.rule.ghost) alpha = Math.sin(w.t * 4.5) > 0.55 ? 0.85 : 0.06;
        if (w.invuln > 0 && Math.floor(w.invuln * 12) % 2 === 0) alpha *= 0.3;
        ctx.globalAlpha = alpha;
        ctx.shadowColor = pal.primary;
        ctx.shadowBlur = 24;
        ctx.fillStyle = pal.primary;
        ctx.beginPath();
        ctx.roundRect(w.paddleX - w.paddleW / 2, w.paddleY - PADDLE_H / 2, w.paddleW, PADDLE_H, 7);
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = pal.accent;
        ctx.fillRect(w.paddleX - w.paddleW / 2 + 10, w.paddleY - 1.5, Math.max(0, w.paddleW - 20), 3);
        ctx.globalAlpha = 1;
      }

      // Particles
      for (const p of w.particles) {
        ctx.globalAlpha = Math.max(0, p.life / p.max);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }

      // Floating score text
      ctx.font = "20px Bungee, sans-serif";
      ctx.textAlign = "center";
      for (const f of w.floaters) {
        ctx.globalAlpha = Math.max(0, f.life / 0.9);
        ctx.fillStyle = f.color;
        ctx.fillText(f.text, f.x, f.y);
      }
      ctx.globalAlpha = 1;

      if (w.flash > 0) {
        ctx.globalAlpha = w.flash * 0.25;
        ctx.fillStyle = w.flashColor;
        ctx.fillRect(-20, -20, W + 40, H + 40);
        ctx.globalAlpha = 1;
      }
      ctx.restore();
    };

    let last = performance.now();
    let raf = 0;
    let lastHud = "";
    const frame = (now: number) => {
      const realDt = Math.min(0.033, (now - last) / 1000);
      last = now;
      const w = worldRef.current;
      const s = statusRef.current;
      w.bgT += realDt * (s === "playing" ? 1 : 0.35);
      if (s === "playing") update(w, realDt);
      else if (s === "over") updateFx(w, realDt);
      draw(w, statusRef.current);

      const combo = comboMultiplier(w.streak);
      const key = `${w.score}|${Math.ceil(w.timeLeft)}|${combo}|${w.shifts}`;
      if (key !== lastHud) {
        lastHud = key;
        setHud({ score: w.score, time: Math.ceil(Math.max(0, w.timeLeft)), combo, shifts: w.shifts });
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [playSound]);

  // Keyboard controls + auto-pause when the tab is hidden.
  useEffect(() => {
    const onKey = (e: KeyboardEvent, down: boolean) => {
      const k = e.key.toLowerCase();
      const playing = statusRef.current === "playing";
      if (k === "arrowleft" || k === "a") {
        inputRef.current.left = down;
        inputRef.current.pointerX = null;
        if (playing) e.preventDefault();
      } else if (k === "arrowright" || k === "d") {
        inputRef.current.right = down;
        inputRef.current.pointerX = null;
        if (playing) e.preventDefault();
      } else if (down && (k === " " || k === "p" || k === "enter")) {
        if (e.target instanceof HTMLButtonElement && k !== "p") return;
        if (k === " " || playing || statusRef.current === "paused") e.preventDefault();
        if (k === "enter" && playing) return;
        togglePause();
      } else if (down && k === "r" && statusRef.current !== "idle") {
        startGame();
      }
    };
    const kd = (e: KeyboardEvent) => onKey(e, true);
    const ku = (e: KeyboardEvent) => onKey(e, false);
    const onHidden = () => {
      if (document.hidden && statusRef.current === "playing") setStatus("paused");
    };
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    document.addEventListener("visibilitychange", onHidden);
    return () => {
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      document.removeEventListener("visibilitychange", onHidden);
    };
  }, [setStatus, startGame, togglePause]);

  // Hide the rule-change banner after its animation.
  useEffect(() => {
    if (!banner) return;
    const id = window.setTimeout(() => setBanner(null), 1700);
    return () => window.clearTimeout(id);
  }, [banner]);

  const toLocalX = (clientX: number) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return W / 2;
    return clamp(((clientX - rect.left) / rect.width) * W, 0, W);
  };

  const hold = (side: "left" | "right", on: boolean) => {
    inputRef.current[side] = on;
    if (on) inputRef.current.pointerX = null;
  };

  const toggleMute = () => {
    mutedRef.current = !mutedRef.current;
    setMuted(mutedRef.current);
  };

  return (
    <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
      <div className="flex flex-col gap-3">
        {/* HUD */}
        <div className="panel mx-auto flex w-full max-w-[min(100%,calc(66svh*0.6774))] min-w-0 items-center justify-between gap-2 px-3 py-2 sm:px-4">
          <div className="flex items-center gap-4">
            <Stat label="Score" value={hud.score} accent="text-accent" />
            <Stat
              label="Best"
              value={best}
              accent="text-gold"
              icon={<Trophy className="size-3" />}
            />
          </div>
          <div
            className={cn(
              "flex items-center gap-1.5 rounded-full border px-3 py-1 font-display text-lg tabular-nums",
              hud.time <= 10 ? "animate-flicker border-bad text-bad" : "border-secondary text-secondary",
            )}
            aria-label={`${hud.time} seconds left`}
          >
            <Timer className="size-4" />
            {Math.floor(hud.time / 60)}:{String(hud.time % 60).padStart(2, "0")}
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMute}
              aria-label={muted ? "Unmute sound" : "Mute sound"}
            >
              {muted ? <VolumeX /> : <Volume2 />}
            </Button>
            <Button variant="ghost" size="icon" onClick={startGame} aria-label="Restart game">
              <RotateCcw />
            </Button>
          </div>
        </div>

        {/* Cabinet */}
        <div className="cabinet mx-auto w-full max-w-[min(100%,calc(66svh*0.6774))]">
          <div className="relative overflow-hidden rounded-[calc(var(--radius-3xl)-3px)] bg-background">
            <canvas
              ref={canvasRef}
              className="no-select block aspect-[420/620] w-full cursor-crosshair"
              onPointerDown={(e) => {
                if (e.pointerType !== "mouse") e.currentTarget.setPointerCapture(e.pointerId);
                inputRef.current.pointerX = toLocalX(e.clientX);
              }}
              onPointerMove={(e) => {
                inputRef.current.pointerX = toLocalX(e.clientX);
              }}
              onPointerUp={(e) => {
                if (e.pointerType !== "mouse") inputRef.current.pointerX = null;
              }}
              onPointerCancel={() => (inputRef.current.pointerX = null)}
              onPointerLeave={() => (inputRef.current.pointerX = null)}
              onContextMenu={(e) => e.preventDefault()}
              aria-label="Rule Breaker game area"
            />

            {status !== "idle" && (
              <div className="pointer-events-none absolute left-3 top-3 flex items-center gap-2">
                <span className="rounded-full border border-secondary/50 bg-background/80 px-3 py-1 font-display text-[10px] uppercase text-secondary">
                  Now: {rule.name}
                </span>
                {hud.combo > 1 && (
                  <span
                    key={hud.combo}
                    className="flex animate-rule-pop items-center gap-1 rounded-full bg-accent px-2 py-1 font-display text-[10px] text-accent-foreground"
                  >
                    <Zap className="size-3" />x{hud.combo}
                  </span>
                )}
              </div>
            )}

            {banner && (
              <div
                key={banner.key}
                className="pointer-events-none absolute left-1/2 top-1/2 w-[86%] animate-banner rounded-2xl border-2 border-accent bg-background/90 px-5 py-4 text-center shadow-neon-primary"
              >
                <div className="flex items-center justify-center gap-2 font-display text-xs uppercase text-accent">
                  <Shuffle className="size-4" /> Rule change!
                </div>
                <div className="mt-1 font-display text-3xl leading-tight text-gradient-brand">
                  {banner.rule.name}
                </div>
                <div className="mt-1 text-sm font-medium text-foreground">
                  {banner.rule.tagline}
                </div>
              </div>
            )}

            {status === "idle" && (
              <Overlay>
                <div className="animate-float font-display text-4xl leading-none text-gradient-brand sm:text-5xl">
                  Rule
                  <br />
                  Breaker
                </div>
                <p className="max-w-[16rem] text-sm text-muted-foreground">
                  Catch <span className="font-semibold text-good">green</span>, dodge{" "}
                  <span className="font-semibold text-bad">red</span>… for now. The rules{" "}
                  <span className="font-semibold text-accent">will</span> change. You won't be
                  warned.
                </p>
                <Button variant="arcade" size="xl" onClick={startGame} autoFocus>
                  <Play /> Press start
                </Button>
                <p className="text-xs text-muted-foreground">
                  ← → or A / D · drag on screen · tap the buttons
                </p>
              </Overlay>
            )}

            {status === "paused" && (
              <Overlay>
                <div className="font-display text-4xl text-secondary neon-secondary">Paused</div>
                <div className="flex gap-2">
                  <Button variant="arcade" size="lg" onClick={togglePause}>
                    <Play /> Resume
                  </Button>
                  <Button variant="arcadeGhost" size="lg" onClick={startGame}>
                    <RotateCcw /> Restart
                  </Button>
                </div>
              </Overlay>
            )}

            {status === "over" && (
              <Overlay>
                <div className="font-display text-4xl text-primary neon-primary sm:text-5xl">
                  Time&apos;s up!
                </div>
                <div>
                  <div className="text-xs uppercase tracking-widest text-muted-foreground">
                    Final score
                  </div>
                  <div className="font-display text-6xl text-accent">{hud.score}</div>
                </div>
                {newBest && (
                  <div className="flex animate-rule-pop items-center gap-2 rounded-full bg-gold px-4 py-1 font-display text-xs uppercase text-primary-foreground">
                    <Trophy className="size-4" /> New best!
                  </div>
                )}
                <p className="text-sm text-muted-foreground">
                  You survived {hud.shifts} rule {hud.shifts === 1 ? "change" : "changes"}.
                </p>
                <Button variant="arcade" size="xl" onClick={startGame} autoFocus>
                  <RotateCcw /> Play again
                </Button>
              </Overlay>
            )}
          </div>
        </div>

        {/* Touch controls */}
        <div className="mx-auto flex w-full max-w-[min(100%,calc(66svh*0.6774))] gap-3">
          <HoldButton label="Move left" onHold={(on) => hold("left", on)}>
            <ChevronLeft className="size-9" />
          </HoldButton>
          <button
            type="button"
            onClick={togglePause}
            aria-label={status === "playing" ? "Pause game" : "Start or resume game"}
            className="no-select flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-neon-primary transition-transform active:scale-90"
          >
            {status === "playing" ? <Pause className="size-7" /> : <Play className="size-7" />}
          </button>
          <HoldButton label="Move right" onHold={(on) => hold("right", on)}>
            <ChevronRight className="size-9" />
          </HoldButton>
        </div>
      </div>

      {/* Side panel */}
      <aside className="flex flex-col gap-4">
        <div key={rule.id + hud.shifts} className="panel animate-rule-pop p-5">
          <div className="flex items-center justify-between">
            <span className="font-display text-[10px] uppercase tracking-wider text-muted-foreground">
              Current rule
            </span>
            <span className="rounded-full bg-muted px-2 py-0.5 font-display text-[10px] text-secondary">
              #{hud.shifts + 1}
            </span>
          </div>
          <h3 className="mt-2 font-display text-2xl text-gradient-brand">{rule.name}</h3>
          <p className="mt-1 text-sm text-foreground">{rule.tagline}</p>

          <ul className="mt-4 space-y-2">
            {(["green", "red", "star"] as ItemKind[]).map((kind) => {
              const res = resolveCatch(rule, kind);
              return (
                <li
                  key={kind}
                  className="flex items-center justify-between rounded-xl bg-background/60 px-3 py-2"
                >
                  <span className="flex items-center gap-2 text-sm">
                    <ItemIcon kind={kind} className="size-6" />
                    {ITEM_LABEL[kind]}
                  </span>
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 font-display text-[10px] uppercase",
                      res.lifeLost
                        ? "bg-bad text-destructive-foreground"
                        : "bg-good text-accent-foreground",
                    )}
                  >
                    {res.lifeLost ? "Avoid!" : `+${res.points}`}
                  </span>
                </li>
              );
            })}
          </ul>
          {rule.dodge && (
            <p className="mt-3 text-xs text-muted-foreground">
              Every orb you let pass earns a point.
            </p>
          )}
        </div>

        <div className="panel p-5">
          <div className="font-display text-[10px] uppercase tracking-wider text-muted-foreground">
            Chaos log
          </div>
          {log.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">
              No surprises yet. Enjoy it while it lasts.
            </p>
          ) : (
            <ol className="mt-3 space-y-2">
              {log.map((entry, i) => (
                <li
                  key={entry.key}
                  className={cn(
                    "flex items-center justify-between text-sm",
                    i === 0 ? "animate-rule-pop text-foreground" : "text-muted-foreground",
                  )}
                >
                  <span className="flex items-center gap-2">
                    <Shuffle className="size-3 text-secondary" />
                    {entry.rule.name}
                  </span>
                  <span className="font-display text-[10px]">{entry.at}s</span>
                </li>
              ))}
            </ol>
          )}
        </div>
      </aside>
    </div>
  );
}

function Stat({
  label,
  value,
  accent,
  icon,
}: {
  label: string;
  value: number;
  accent: string;
  icon?: ReactNode;
}) {
  return (
    <div className="leading-none">
      <div className="flex items-center gap-1 text-[10px] uppercase tracking-widest text-muted-foreground">
        {icon}
        {label}
      </div>
      <div className={cn("mt-1 font-display text-xl tabular-nums", accent)}>{value}</div>
    </div>
  );
}

function Overlay({ children }: { children: ReactNode }) {
  return (
    <div className="absolute inset-0 flex animate-rule-pop flex-col items-center justify-center gap-4 bg-background/75 p-6 text-center backdrop-blur-sm">
      {children}
    </div>
  );
}

function HoldButton({
  label,
  onHold,
  children,
}: {
  label: string;
  onHold: (on: boolean) => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      className="no-select flex h-16 flex-1 items-center justify-center rounded-2xl border-2 border-secondary/60 bg-surface text-secondary shadow-neon-secondary transition-transform active:scale-95 active:bg-secondary active:text-secondary-foreground"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        onHold(true);
      }}
      onPointerUp={() => onHold(false)}
      onPointerCancel={() => onHold(false)}
      onLostPointerCapture={() => onHold(false)}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}
