import { createFileRoute } from "@tanstack/react-router";
import { Gamepad2, Shuffle } from "lucide-react";

import { ItemIcon } from "@/components/arcade/ItemIcon";
import { RuleBreakerGame } from "@/components/arcade/RuleBreakerGame";
import { Button } from "@/components/ui/button";
import { RULES } from "@/lib/game/rules";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Glitch Arcade — Rule Breaker, the game that changes its rules" },
      {
        name: "description",
        content:
          "Play Rule Breaker: a neon arcade catch game whose rules flip without warning. Track your score, beat your best, play on phone or desktop.",
      },
      { property: "og:title", content: "Glitch Arcade — Rule Breaker" },
      {
        property: "og:description",
        content: "One game. Zero stable rules. Catch, dodge and adapt as the rules change mid-play.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const marquee = RULES.map((r) => r.name);

  return (
    <div className="min-h-screen overflow-x-hidden">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <a href="#top" className="flex items-center gap-2">
          <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-neon-primary">
            <Gamepad2 className="size-5" />
          </span>
          <span className="font-display text-lg leading-none">
            Glitch<span className="text-secondary">Arcade</span>
          </span>
        </a>
        <nav className="flex items-center gap-1 text-sm sm:gap-4">
          <a href="#play" className="px-2 py-1 text-muted-foreground hover:text-foreground">
            Play
          </a>
          <a href="#rules" className="px-2 py-1 text-muted-foreground hover:text-foreground">
            Rulebook
          </a>
          <span className="hidden animate-flicker rounded-full border border-accent px-3 py-1 font-display text-[10px] uppercase text-accent sm:inline">
            Free play
          </span>
        </nav>
      </header>

      <main id="top">
        {/* Hero */}
        <section className="arcade-grid relative">
          <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr] md:py-20">
            <div>
              <p className="font-display text-xs uppercase tracking-widest text-secondary">
                1 cabinet · ∞ surprises
              </p>
              <h1 className="mt-4 font-display text-5xl leading-[0.95] sm:text-7xl">
                One game.
                <br />
                <span className="text-gradient-brand">Zero stable rules.</span>
              </h1>
              <p className="mt-6 max-w-md text-lg text-muted-foreground">
                Catch, dodge, adapt. Just when you get good, Rule Breaker flips colors, gravity,
                controls — everything.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button variant="arcade" size="xl" asChild>
                  <a href="#play">Insert coin</a>
                </Button>
                <Button variant="arcadeGhost" size="xl" asChild>
                  <a href="#rules">Read the rules</a>
                </Button>
              </div>
            </div>
            <div className="relative hidden h-72 md:block" aria-hidden="true">
              <ItemIcon kind="green" className="absolute left-6 top-4 size-24 animate-float" />
              <ItemIcon
                kind="red"
                className="absolute right-4 top-16 size-28 animate-float [animation-delay:-1.3s]"
              />
              <ItemIcon
                kind="star"
                className="absolute bottom-6 left-1/3 size-24 animate-float [animation-delay:-2.4s]"
              />
              <div className="absolute bottom-0 left-1/2 h-4 w-40 -translate-x-1/2 rounded-full bg-primary shadow-neon-primary" />
            </div>
          </div>
        </section>

        {/* Marquee */}
        <div className="overflow-hidden border-y border-border bg-surface py-3">
          <div className="flex w-max animate-marquee gap-8 font-display text-sm uppercase text-muted-foreground">
            {[...marquee, ...marquee].map((name, i) => (
              <span key={i} className="flex items-center gap-8">
                {name}
                <Shuffle className="size-4 text-primary" />
              </span>
            ))}
          </div>
        </div>

        {/* Game */}
        <section id="play" className="mx-auto max-w-6xl scroll-mt-4 px-4 py-10 sm:px-6 md:py-16">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-2">
            <h2 className="font-display text-3xl sm:text-4xl">
              Rule <span className="text-primary neon-primary">Breaker</span>
            </h2>
            <p className="text-sm text-muted-foreground">
              3 lives · combos up to x5 · best score saved on this device
            </p>
          </div>
          <RuleBreakerGame />
        </section>

        {/* Rulebook */}
        <section id="rules" className="mx-auto max-w-6xl scroll-mt-4 px-4 pb-20 sm:px-6">
          <h2 className="font-display text-3xl sm:text-4xl">
            The rulebook <span className="text-secondary neon-secondary">of chaos</span>
          </h2>
          <p className="mt-2 max-w-xl text-muted-foreground">
            Every 7–13 seconds, one of these takes over. No countdown. No mercy. Gold stars are
            always safe.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {RULES.map((rule, i) => (
              <article
                key={rule.id}
                className="panel group p-4 transition-transform hover:-translate-y-1 hover:rotate-[-1deg] hover:border-secondary"
              >
                <span className="font-display text-[10px] text-muted-foreground">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-1 font-display text-lg leading-tight group-hover:text-secondary">
                  {rule.name}
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">{rule.tagline}</p>
                <span className="mt-3 inline-block rounded-full bg-muted px-2 py-0.5 font-display text-[10px] text-accent">
                  x{rule.points} pts
                </span>
              </article>
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-6 text-center text-xs text-muted-foreground">
        Glitch Arcade · Press R to restart, Space to pause
      </footer>
    </div>
  );
}
