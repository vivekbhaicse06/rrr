import type { ItemKind } from "@/lib/game/rules";
import { cn } from "@/lib/utils";

function starPoints(spikes: number, outer: number, inner: number, cx = 50, cy = 50) {
  const pts: string[] = [];
  for (let i = 0; i < spikes * 2; i++) {
    const r = i % 2 === 0 ? outer : inner;
    const a = (Math.PI / spikes) * i - Math.PI / 2;
    pts.push(`${(cx + Math.cos(a) * r).toFixed(1)},${(cy + Math.sin(a) * r).toFixed(1)}`);
  }
  return pts.join(" ");
}

export function ItemIcon({ kind, className }: { kind: ItemKind; className?: string }) {
  return (
    <svg viewBox="0 0 100 100" className={cn("size-8", className)} aria-hidden="true">
      {kind === "green" && (
        <>
          <circle cx="50" cy="50" r="38" className="fill-good" />
          <circle cx="38" cy="38" r="10" className="fill-foreground opacity-50" />
        </>
      )}
      {kind === "red" && <polygon points={starPoints(8, 44, 24)} className="fill-bad" />}
      {kind === "star" && <polygon points={starPoints(5, 46, 20)} className="fill-gold" />}
    </svg>
  );
}

export const ITEM_LABEL: Record<ItemKind, string> = {
  green: "Green orb",
  red: "Red spike",
  star: "Gold star",
};
