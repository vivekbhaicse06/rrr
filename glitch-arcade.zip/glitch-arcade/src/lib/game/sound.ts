let ctx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function tone(freq: number, duration: number, type: OscillatorType, gain = 0.08, slideTo?: number) {
  const ac = getCtx();
  if (!ac) return;
  const osc = ac.createOscillator();
  const g = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, ac.currentTime);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, ac.currentTime + duration);
  g.gain.setValueAtTime(gain, ac.currentTime);
  g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + duration);
  osc.connect(g).connect(ac.destination);
  osc.start();
  osc.stop(ac.currentTime + duration);
}

export const sfx = {
  catch: () => tone(660, 0.12, "square", 0.05, 990),
  star: () => {
    tone(880, 0.1, "triangle", 0.07);
    setTimeout(() => tone(1320, 0.18, "triangle", 0.07), 80);
  },
  hit: () => tone(200, 0.35, "sawtooth", 0.08, 60),
  shift: () => {
    tone(300, 0.15, "square", 0.06, 600);
    setTimeout(() => tone(600, 0.25, "square", 0.06, 200), 140);
  },
  over: () => tone(400, 0.9, "sawtooth", 0.08, 50),
  start: () => tone(440, 0.2, "triangle", 0.07, 880),
};
