import { describe, expect, it } from "vitest";

import {
  comboMultiplier,
  getRule,
  nextShiftDelay,
  pickNextRule,
  resolveCatch,
  RULES,
} from "./rules";

describe("Rule Breaker rules", () => {
  it("classic: green scores, red costs a life", () => {
    const r = getRule("classic");
    expect(resolveCatch(r, "green")).toEqual({ points: 1, lifeLost: false });
    expect(resolveCatch(r, "red")).toEqual({ points: 0, lifeLost: true });
  });

  it("color swap: red scores, green costs a life", () => {
    const r = getRule("swap");
    expect(resolveCatch(r, "red").lifeLost).toBe(false);
    expect(resolveCatch(r, "green").lifeLost).toBe(true);
  });

  it("hot potato: touching green or red costs a life, stars stay safe", () => {
    const r = getRule("dodge");
    expect(resolveCatch(r, "green").lifeLost).toBe(true);
    expect(resolveCatch(r, "red").lifeLost).toBe(true);
    expect(resolveCatch(r, "star").lifeLost).toBe(false);
  });

  it("stars are worth 5 times the rule's point multiplier", () => {
    expect(resolveCatch(getRule("turbo"), "star").points).toBe(10);
  });

  it("combo goes up by one every 5 catches and caps at x5", () => {
    expect(comboMultiplier(4)).toBe(1);
    expect(comboMultiplier(5)).toBe(2);
    expect(comboMultiplier(100)).toBe(5);
  });

  it("a rule change never repeats the current rule", () => {
    for (const rule of RULES) {
      for (let i = 0; i < 10; i++) {
        expect(pickNextRule(rule.id, () => i / 10).id).not.toBe(rule.id);
      }
    }
  });

  it("rule changes happen between 7 and 13 seconds apart", () => {
    expect(nextShiftDelay(() => 0)).toBe(7);
    expect(nextShiftDelay(() => 0.999)).toBeLessThan(13);
  });
});
