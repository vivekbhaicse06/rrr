# Roadmap

- [x] Arcade design system (neon colors, fonts, animations)
- [x] Game rules logic + tests
- [x] Rule Breaker game (canvas, score, lives, restart, mobile controls, surprise rule changes)
- [x] Arcade home page (hero, game, rulebook)
- [x] Fix any errors and verify the working preview with screenshots
