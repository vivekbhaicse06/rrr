<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules

- Game rules live as pure data/functions in `src/lib/game/rules.ts` (tested in `rules.test.ts`); the canvas component only reads them — keeps rule behavior testable without a browser.
- The game loop runs on refs + requestAnimationFrame and syncs to React state only when HUD values change — avoids re-rendering every frame.
- Canvas colors are read from the CSS design tokens at mount — keeps the game in sync with `src/styles.css`.
