export type ItemKind = "green" | "red" | "star";

export type RuleId =
  | "classic"
  | "swap"
  | "reverse"
  | "flip"
  | "turbo"
  | "tiny"
  | "ghost"
  | "dodge"
  | "feast"
  | "wind";

export interface Rule {
  id: RuleId;
  name: string;
  tagline: string;
  /** Item kinds that award points when caught. Others cost a life. */
  good: ItemKind[];
  /** Dodge mode: any green/red caught costs a life; points come from surviving. */
  dodge?: boolean;
  /** Left/right controls are mirrored. */
  reverse?: boolean;
  /** Items fall upward and the paddle moves to the top. */
  flip?: boolean;
  /** Paddle flickers nearly invisible. */
  ghost?: boolean;
  /** Horizontal drift strength applied to falling items. */
  wind?: number;
  /** Fall speed multiplier. */
  speed: number;
  /** Paddle width multiplier. */
  paddle: number;
  /** Point multiplier. */
  points: number;
}

export const RULES: Rule[] = [
  {
    id: "classic",
    name: "Classic",
    tagline: "Catch GREEN. Avoid RED.",
    good: ["green"],
    speed: 1,
    paddle: 1,
    points: 1,
  },
  {
    id: "swap",
    name: "Color Swap",
    tagline: "RED is good now. GREEN bites!",
    good: ["red"],
    speed: 1,
    paddle: 1,
    points: 1,
  },
  {
    id: "reverse",
    name: "Mirror Hands",
    tagline: "Left is right. Right is left.",
    good: ["green"],
    reverse: true,
    speed: 0.9,
    paddle: 1.1,
    points: 2,
  },
  {
    id: "flip",
    name: "Gravity Flip",
    tagline: "Everything falls UP.",
    good: ["green"],
    flip: true,
    speed: 0.95,
    paddle: 1,
    points: 2,
  },
  {
    id: "turbo",
    name: "Turbo",
    tagline: "Double speed. Double points.",
    good: ["green"],
    speed: 1.75,
    paddle: 1.15,
    points: 2,
  },
  {
    id: "tiny",
    name: "Shrink Ray",
    tagline: "Your paddle got tiny.",
    good: ["green"],
    speed: 0.85,
    paddle: 0.5,
    points: 3,
  },
  {
    id: "ghost",
    name: "Ghost Mode",
    tagline: "Where did your paddle go?",
    good: ["green"],
    ghost: true,
    speed: 0.9,
    paddle: 1.1,
    points: 2,
  },
  {
    id: "dodge",
    name: "Hot Potato",
    tagline: "Touch NOTHING. Stars are safe.",
    good: [],
    dodge: true,
    speed: 1.1,
    paddle: 1,
    points: 1,
  },
  {
    id: "feast",
    name: "Feast",
    tagline: "Everything is delicious!",
    good: ["green", "red"],
    speed: 1.2,
    paddle: 1,
    points: 1,
  },
  {
    id: "wind",
    name: "Hurricane",
    tagline: "Catch GREEN… if the wind lets you.",
    good: ["green"],
    wind: 140,
    speed: 0.9,
    paddle: 1,
    points: 2,
  },
];

export const STAR_POINTS = 5;
/** Length of a round in seconds. */
export const ROUND_SECONDS = 60;
/** Seconds lost when catching a bad item. */
export const TIME_PENALTY = 5;

export function getRule(id: RuleId): Rule {
  const rule = RULES.find((r) => r.id === id);
  if (!rule) throw new Error(`Unknown rule: ${id}`);
  return rule;
}

export interface CatchResult {
  points: number;
  lifeLost: boolean;
}

/** What happens when the paddle touches an item under the given rule (before combo bonus). */
export function resolveCatch(rule: Rule, kind: ItemKind): CatchResult {
  if (kind === "star") return { points: STAR_POINTS * rule.points, lifeLost: false };
  if (rule.dodge) return { points: 0, lifeLost: true };
  if (rule.good.includes(kind)) return { points: rule.points, lifeLost: false };
  return { points: 0, lifeLost: true };
}

/** Combo multiplier: +1 for every 5 good catches in a row, capped at x5. */
export function comboMultiplier(streak: number): number {
  return Math.min(5, 1 + Math.floor(streak / 5));
}

/** Pick a different rule than the current one. */
export function pickNextRule(currentId: RuleId, rand: () => number = Math.random): Rule {
  const pool = RULES.filter((r) => r.id !== currentId);
  return pool[Math.floor(rand() * pool.length) % pool.length] ?? RULES[0]!;
}

/** Seconds until the next surprise rule change (7–13s). */
export function nextShiftDelay(rand: () => number = Math.random): number {
  return 7 + rand() * 6;
}
